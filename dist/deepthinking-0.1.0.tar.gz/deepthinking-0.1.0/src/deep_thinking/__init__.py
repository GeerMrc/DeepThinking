"""DeepThinking-MCP: 高级深度思考MCP服务器"""

__version__ = "0.1.0"
